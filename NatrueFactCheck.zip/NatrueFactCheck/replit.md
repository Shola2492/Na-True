# Overview

NaTrue is a Nigerian fact-checking platform built with Flask that helps users verify claims and combat misinformation. The application provides a web interface for users to search for fact-checked claims, submit new claims for verification, and learn about media literacy.

# System Architecture

The application follows a simple Flask web application architecture:

- **Frontend**: HTML templates with Bootstrap 5 for styling and responsive design
- **Backend**: Flask web framework with Python 3.11
- **Static Assets**: CSS and JavaScript files for client-side functionality
- **Deployment**: Gunicorn WSGI server for production deployment

The application is designed to be lightweight and scalable, using Flask's built-in templating system and modern web technologies.

# Key Components

## Flask Application Structure
- `main.py`: Entry point that runs the Flask application
- `app.py`: Main application configuration and sample data
- `templates/`: Jinja2 templates for HTML rendering
  - `base.html`: Base template with navigation and common elements
  - `index.html`: Homepage with search functionality
- `static/`: Static assets (CSS, JavaScript, images)
  - `css/style.css`: Custom styling with CSS variables
  - `js/main.js`: Client-side JavaScript functionality

## Data Management
Currently uses in-memory data storage with `FACT_CHECKED_POSTS` list containing sample fact-checked claims. Each post includes:
- Claim text
- Status (TRUE/FALSE/MISLEADING)
- Explanation
- Source attribution

## Frontend Features
- Responsive Bootstrap 5 design
- Search functionality for fact-checking claims
- Navigation system with multiple sections
- Custom CSS with CSS variables for consistent theming
- JavaScript enhancements for user experience

# Data Flow

1. User accesses the web application through their browser
2. Flask serves HTML templates populated with data
3. User interactions (search, navigation) trigger HTTP requests
4. Flask processes requests and returns appropriate responses
5. Static assets (CSS, JS) enhance the user interface

# External Dependencies

## Python Packages
- `flask>=3.1.1`: Web framework
- `flask-sqlalchemy>=3.1.1`: Database ORM (prepared for future database integration)
- `gunicorn>=23.0.0`: WSGI server for production
- `psycopg2-binary>=2.9.10`: PostgreSQL adapter (prepared for database integration)
- `email-validator>=2.2.0`: Email validation utility

## Frontend Dependencies
- Bootstrap 5: CSS framework for responsive design
- Font Awesome 6: Icon library
- Modern browser JavaScript APIs

# Deployment Strategy

The application is configured for deployment on Replit with:

- **Development**: Flask development server with hot reload
- **Production**: Gunicorn WSGI server binding to `0.0.0.0:5000`
- **Environment**: Python 3.11 with Nix package management
- **Database Ready**: PostgreSQL package included for future database integration
- **Autoscaling**: Configured for Replit's autoscale deployment target

The deployment uses parallel workflows for development and production environments, with proper port configuration and reload capabilities.

# Recent Changes

## June 24, 2025 - Enhanced Functionality
- ✓ Created comprehensive Submit a Claim page with full form validation
- ✓ Built educational Learn Media Literacy page with interactive assessment
- ✓ Developed Community page with engagement features and guidelines
- ✓ Added functional Fact-Check Feed with filtering and social sharing
- ✓ Implemented form processing for claim submissions
- ✓ Added modals for detailed educational content and reporting features
- ✓ Enhanced navigation with fully functional page routing

## Initial Setup - June 24, 2025
- Basic Flask application structure created
- Homepage with search functionality implemented
- Sample fact-checked data integration
- Bootstrap styling and responsive design

# User Preferences

```
Preferred communication style: Simple, everyday language.
```