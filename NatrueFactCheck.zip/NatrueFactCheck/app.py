import os
import logging
from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.DEBUG)

class Base(DeclarativeBase):
    pass

db = SQLAlchemy(model_class=Base)

# Create the app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key-change-in-production")

# Configure database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}

# Initialize database
db.init_app(app)

# Define database models
class ClaimSubmission(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    claim_text = db.Column(db.Text, nullable=False)
    source_url = db.Column(db.String(500))
    context = db.Column(db.Text)
    category = db.Column(db.String(50), nullable=False)
    urgency = db.Column(db.String(20), nullable=False)
    contact_email = db.Column(db.String(120))
    status = db.Column(db.String(20), default='PENDING')  # PENDING, REVIEWING, VERIFIED, REJECTED
    fact_check_result = db.Column(db.String(20))  # TRUE, FALSE, MISLEADING
    fact_check_explanation = db.Column(db.Text)
    fact_check_sources = db.Column(db.Text)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)
    reviewed_at = db.Column(db.DateTime)
    reviewer_notes = db.Column(db.Text)
    
    def __repr__(self):
        return f'<ClaimSubmission {self.id}: {self.claim_text[:50]}...>'

# Create tables
with app.app_context():
    db.create_all()

# Sample fact-checked posts data
FACT_CHECKED_POSTS = [
    {
        "claim": "COVID-19 vaccines contain microchips for tracking people",
        "status": "FALSE",
        "explanation": "No credible evidence supports this claim. COVID-19 vaccines contain mRNA or viral proteins, not microchips.",
        "source": "WHO, CDC"
    },
    {
        "claim": "Nigeria's economy grew by 15% in 2024",
        "status": "MISLEADING",
        "explanation": "Nigeria's GDP growth was 3.2% in 2024, not 15%. The figure may have been confused with another metric.",
        "source": "NBS, CBN"
    },
    {
        "claim": "Drinking warm water with lemon prevents malaria",
        "status": "FALSE",
        "explanation": "There is no scientific evidence that lemon water prevents malaria. Only proven methods like bed nets and antimalarial drugs are effective.",
        "source": "Nigerian Medical Association"
    },
    {
        "claim": "INEC announced new voter registration deadline",
        "status": "TRUE",
        "explanation": "INEC officially extended voter registration deadline to December 2024 as announced on their official channels.",
        "source": "INEC Official Statement"
    },
    {
        "claim": "Solar panels work efficiently during Nigeria's rainy season",
        "status": "TRUE",
        "explanation": "Solar panels can generate electricity even on cloudy days, though efficiency is reduced. They remain viable year-round in Nigeria.",
        "source": "Renewable Energy Association of Nigeria"
    },
    {
        "claim": "New fuel subsidy removal will reduce petrol price by 50%",
        "status": "MISLEADING",
        "explanation": "Subsidy removal typically increases fuel prices in the short term. Long-term effects depend on market dynamics and government policies.",
        "source": "Nigerian National Petroleum Corporation"
    }
]

FLAGGED_TOPICS = [
    "COVID-19 Misinformation",
    "Election Security",
    "Economic Data Manipulation",
    "Health Remedy Scams",
    "Government Policy Claims"
]

@app.route('/')
def index():
    """Homepage route"""
    return render_template('index.html', 
                         fact_checked_posts=FACT_CHECKED_POSTS,
                         flagged_topics=FLAGGED_TOPICS)

@app.route('/search', methods=['GET', 'POST'])
def search():
    """Search functionality"""
    if request.method == 'POST':
        query = request.form.get('query', '').strip()
        if query:
            # Filter posts based on search query
            filtered_posts = [
                post for post in FACT_CHECKED_POSTS 
                if query.lower() in post['claim'].lower() or 
                   query.lower() in post['explanation'].lower()
            ]
            flash(f'Found {len(filtered_posts)} results for "{query}"', 'info')
            return render_template('index.html', 
                                 fact_checked_posts=filtered_posts,
                                 flagged_topics=FLAGGED_TOPICS,
                                 search_query=query)
        else:
            flash('Please enter a search term', 'warning')
    
    return redirect(url_for('index'))

@app.route('/submit', methods=['GET', 'POST'])
def submit_claim():
    """Submit a claim page"""
    if request.method == 'POST':
        claim_text = request.form.get('claim_text', '').strip()
        source_url = request.form.get('source_url', '').strip()
        context = request.form.get('context', '').strip()
        category = request.form.get('category', '')
        urgency = request.form.get('urgency', '')
        contact_email = request.form.get('contact_email', '').strip()
        
        if not claim_text:
            flash('Please provide the claim text.', 'danger')
            return redirect(url_for('submit_claim'))
        
        if not category:
            flash('Please select a category.', 'danger')
            return redirect(url_for('submit_claim'))
            
        if not urgency:
            flash('Please select an urgency level.', 'danger')
            return redirect(url_for('submit_claim'))
        
        try:
            # Save to database
            new_submission = ClaimSubmission(
                claim_text=claim_text,
                source_url=source_url if source_url else None,
                context=context if context else None,
                category=category,
                urgency=urgency,
                contact_email=contact_email if contact_email else None,
                status='PENDING'
            )
            
            db.session.add(new_submission)
            db.session.commit()
            
            flash(f'Thank you! Your claim has been submitted for fact-checking. Submission ID: #{new_submission.id}', 'success')
            
            if contact_email:
                flash(f'We\'ll send updates to {contact_email} when the fact-check is complete.', 'info')
            
            # In a real system, this would trigger the fact-checking workflow
            logging.info(f"New claim submitted: ID {new_submission.id}, Category: {category}, Urgency: {urgency}")
            
        except Exception as e:
            db.session.rollback()
            logging.error(f"Error saving claim submission: {e}")
            flash('There was an error submitting your claim. Please try again.', 'danger')
            return redirect(url_for('submit_claim'))
        
        return redirect(url_for('index'))
    
    return render_template('submit_claim.html')

@app.route('/feed')
def fact_check_feed():
    """Fact-check feed page"""
    # Add category information to posts for filtering
    enhanced_posts = []
    categories = ['health', 'politics', 'economy', 'science', 'social', 'security']
    
    for i, post in enumerate(FACT_CHECKED_POSTS):
        enhanced_post = post.copy()
        enhanced_post['category'] = categories[i % len(categories)]
        enhanced_post['date_checked'] = f"{(i % 7) + 1} days ago"
        enhanced_posts.append(enhanced_post)
    
    return render_template('feed.html', fact_checked_posts=enhanced_posts)

@app.route('/learn')
def learn():
    """Learn media literacy page"""
    return render_template('learn.html')

@app.route('/community')
def community():
    """Community page"""
    return render_template('community.html')

@app.route('/admin')
def admin_dashboard():
    """Admin dashboard for reviewing submissions"""
    try:
        # Get all submissions
        submissions = ClaimSubmission.query.order_by(ClaimSubmission.submitted_at.desc()).all()
        
        # Calculate statistics
        stats = {
            'pending': ClaimSubmission.query.filter_by(status='PENDING').count(),
            'reviewing': ClaimSubmission.query.filter_by(status='REVIEWING').count(),
            'verified': ClaimSubmission.query.filter_by(status='VERIFIED').count(),
            'rejected': ClaimSubmission.query.filter_by(status='REJECTED').count()
        }
        
        pending_count = stats['pending']
        
        return render_template('admin.html', 
                             submissions=submissions, 
                             stats=stats, 
                             pending_count=pending_count)
        
    except Exception as e:
        logging.error(f"Error loading admin dashboard: {e}")
        flash('Error loading dashboard. Please try again.', 'danger')
        return redirect(url_for('index'))

@app.route('/admin/start-review/<int:submission_id>', methods=['POST'])
def start_review(submission_id):
    """Start reviewing a claim submission"""
    try:
        submission = ClaimSubmission.query.get_or_404(submission_id)
        submission.status = 'REVIEWING'
        db.session.commit()
        
        return {'success': True, 'message': 'Review started successfully'}
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error starting review: {e}")
        return {'success': False, 'message': str(e)}

@app.route('/admin/complete-fact-check/<int:submission_id>', methods=['POST'])
def complete_fact_check(submission_id):
    """Complete fact-checking for a submission"""
    try:
        data = request.get_json()
        submission = ClaimSubmission.query.get_or_404(submission_id)
        
        submission.status = 'VERIFIED'
        submission.fact_check_result = data['result']
        submission.fact_check_explanation = data['explanation']
        submission.fact_check_sources = data['sources']
        submission.reviewer_notes = data.get('notes', '')
        submission.reviewed_at = datetime.utcnow()
        
        db.session.commit()
        
        # Add to the public fact-checked posts
        new_post = {
            'claim': submission.claim_text,
            'status': submission.fact_check_result,
            'explanation': submission.fact_check_explanation,
            'source': submission.fact_check_sources,
            'category': submission.category,
            'date_checked': 'Today'
        }
        FACT_CHECKED_POSTS.append(new_post)
        
        return {'success': True, 'message': 'Fact-check completed successfully'}
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error completing fact-check: {e}")
        return {'success': False, 'message': str(e)}

@app.route('/admin/reject-claim/<int:submission_id>', methods=['POST'])
def reject_claim(submission_id):
    """Reject a claim submission"""
    try:
        data = request.get_json()
        submission = ClaimSubmission.query.get_or_404(submission_id)
        
        submission.status = 'REJECTED'
        submission.reviewer_notes = f"Rejected: {data.get('reason', 'No reason provided')}"
        submission.reviewed_at = datetime.utcnow()
        
        db.session.commit()
        
        return {'success': True, 'message': 'Claim rejected successfully'}
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error rejecting claim: {e}")
        return {'success': False, 'message': str(e)}

@app.route('/admin/add-notes/<int:submission_id>', methods=['POST'])
def add_notes(submission_id):
    """Add internal notes to a submission"""
    try:
        data = request.get_json()
        submission = ClaimSubmission.query.get_or_404(submission_id)
        
        current_notes = submission.reviewer_notes or ""
        new_notes = f"{current_notes}\n[{datetime.utcnow().strftime('%Y-%m-%d %H:%M')}] {data['notes']}"
        submission.reviewer_notes = new_notes.strip()
        
        db.session.commit()
        
        return {'success': True, 'message': 'Notes added successfully'}
    except Exception as e:
        db.session.rollback()
        logging.error(f"Error adding notes: {e}")
        return {'success': False, 'message': str(e)}

@app.route('/admin/publish-to-feed/<int:submission_id>', methods=['POST'])
def publish_to_feed(submission_id):
    """Publish a verified fact-check to the public feed"""
    try:
        submission = ClaimSubmission.query.get_or_404(submission_id)
        
        if submission.status != 'VERIFIED' or not submission.fact_check_result:
            return {'success': False, 'message': 'Only verified fact-checks can be published'}
        
        # In a real system, this would add to a published posts table
        # For now, we'll just confirm it's already in the FACT_CHECKED_POSTS
        logging.info(f"Published fact-check for submission {submission_id} to public feed")
        
        return {'success': True, 'message': 'Fact-check published to feed'}
    except Exception as e:
        logging.error(f"Error publishing to feed: {e}")
        return {'success': False, 'message': str(e)}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
