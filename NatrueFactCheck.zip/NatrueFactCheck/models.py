from datetime import datetime

# We'll define models directly in app.py to avoid circular imports